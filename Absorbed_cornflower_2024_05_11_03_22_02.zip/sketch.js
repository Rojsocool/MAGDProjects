function setup() {
  createCanvas(300, 300);
}

function draw() {
  background(220);
 
  
rect(130,170,50,200);

  rect(145,270,20,50);

  ellipse(43,46,55,55);

  ellipse(150,290,5,5);
 
  line(55,77,90,100);
  
  line(77,45,120,70);
  
  point(43,44);
  point(45,63)
  
}

var word1, pic1;
var word2, pic2;
var title;
var pitch;

function preload() {
  pic1 = loadImage("images/OnePiece.jpg");
  word1 = loadFont("fonts/font1.ttf");
  pic2 = loadImage("images/OnePiece2.jpg");
  word2 = loadFont("fonts/font2.ttf");
}

function setup() {
  createCanvas(400, 400);
  title = "One Piece Wano Arc Movie!"
  pitch = "Join Luffy and his crew through the land of Wano"
}

function draw() {
  background(220);
  push();
  pic1.filter(OPAQUE);
  image(pic1, 0, 0, width/2, height);
  
  pop();
  
  push();
  pic2.filter(BLUR)

  image(pic2, 200, 0, width/2, height);
  pop();
  
  push();
  fill(255);
  translate(width/2, 50);
  textSize(48);
  textFont(word1);
  textAlign(CENTER);
  text(title,0,0);
  pop();
  
  push();
  fill(0);
  textAlign(LEFT);
  textSize(20);
  textFont(word2);
  text(pitch, 10, height-80);
  pop();
  
}

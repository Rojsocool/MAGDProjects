function setup() {
  createCanvas(400, 400);
}

function draw() {
  colorMode(HSB);
  background(255, 204, 100);

  push();
  colorMode(HSB);
  fill(172,82,67);
  arc(200,200,150,150,0,-4*PI)
  pop();

  push();
  colorMode(RGB);
  fill(0,0,225);
  triangle(150,90,264,90,207,40);
  pop();
  
  push();
  colorMode(RGB)
  fill(225,0,0)
  arc(207,60,25,25,0,-4*PI);
  pop();
  
  push();
  colorMode(RGB)
  fill(0,225,0)
  beginShape();
  vertex(180,90);
  vertex(180,130);
  vertex(230,130);
  vertex(230,90);
  endShape(CLOSE);
  pop();
}